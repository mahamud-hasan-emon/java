package hashtable;
import java.util.*;
public class HashTableExample{

    public static void main(String[] args) {
       
        // Create a Hashtable to store Country = Capital
        Hashtable<String, String> countryTable = new Hashtable<String, String>();

        // Add Some Countries and their capitals
        countryTable.put("Bangladesh", "Dhaka");
        countryTable.put("India", "New Delhi");
        countryTable.put("USA", "Washington DC");
        countryTable.put("Japan", "Tokyo");
        countryTable.put("Canada", "Ottawa");
        countryTable.put("Finland", "Helsinki");
        countryTable.put("Norway", "Oslo");
        countryTable.put("Denmark", "Copenhagen");

        // Print the full table
        System.out.println("Country Capital Table: " + countryTable);
        Scanner sc = new Scanner(System.in);

        // Retrieve the capital of a country
        System.out.print("Enter country name to get capital: ");
        String search = sc.nextLine();
        System.out.println("Capital of " + search + " is: " + countryTable.get(search));

        // Remove a country
        System.out.print("Enter country name to remove: ");
        String removeCountry = sc.nextLine();
        countryTable.remove(removeCountry);
        System.out.println("After removing: " + countryTable);

        // Check if a key exists
        System.out.print("Enter a country to check if exists: ");
        String keyCheck = sc.nextLine();
        System.out.println("Key Exists:" + countryTable.containsKey(keyCheck));

        // Check if a value exists
        System.out.print("Enter a capital to check if exists: ");
        String valueCheck = sc.nextLine();
        System.out.println("Value Exists: " + countryTable.containsValue(valueCheck));

        // Print all entries (Country = Capital)
        System.out.println("All Entries: " + countryTable.entrySet());

        // Inserting null key (Hashtable does not allow null keys)
        try {
            countryTable.put(null, "Test");
        } catch (Exception e) {
            System.out.println("Error inserting null key: " + e);
        }

        // Try inserting a null value (Hashtable does not allow null values)
        try {
            countryTable.put("NullCountry", null);
        } catch (Exception e) {
            System.out.println("Error inserting null value: " + e);
        }

    }
    
}
