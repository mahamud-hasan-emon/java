package hashmap;  
import java.util.*;       
public class HashMapExample {  

    public static void main(String[] args) {

        // Creating a HashMap with Integer key & String value
        HashMap<Integer, String> myMap = new HashMap<Integer, String>();

        // Insert Key–Value Pairs
        myMap.put(419, "Sujon");
        myMap.put(404, "Kawsar");
        myMap.put(407, "Al-Amin");
        myMap.put(405, "Emon");
        myMap.put(420, "Minhaz");
        myMap.put(425, "Farhan");
        myMap.put(410, "Mahin");
        myMap.put(415, "Jibon");

        // Print full HashMap
        System.out.println("Student HashMap = " + myMap);
        Scanner sc = new Scanner(System.in);

        // Search a Student by ID
        System.out.print("Enter a Student ID to search: ");
        int searchID = sc.nextInt();
        System.out.println("Student with ID " + searchID + " = " + myMap.get(searchID));
        
        // Update a Student Name
        System.out.print("Enter a Student ID to update name: ");
        int updateID = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter new name: ");
        String newName = sc.nextLine();
        myMap.replace(updateID, newName); 
        System.out.println("Updated HashMap = " + myMap);

        // Remove a Student
        System.out.print("Enter a Student ID to remove: ");
        int removeID = sc.nextInt();
        String removed = myMap.remove(removeID);          
        System.out.println("Removed Student: " + removed);
        System.out.println("HashMap After Removal = " + myMap);

        // Print All Entries
        System.out.println("All Students (ID = Name): " + myMap.entrySet());
        
        // Check if Key Exists
        System.out.print("Enter a Student ID to check if exists: ");
        int keyCheck = sc.nextInt();
        System.out.println("Key Exists: " + myMap.containsKey(keyCheck));        

        // Check if Value Exists
        sc.nextLine(); 
        System.out.print("Enter a Student Name to check if exists: ");
        String valueCheck = sc.nextLine();
        System.out.println("Value Exists: " + myMap.containsValue(valueCheck));        
    }    
}
