package hashset;
import java.util.*;
public class HashSetExample {

    public static void main(String[] args) {
        //Create ArrayList to store student name
        ArrayList<String> list = new ArrayList<>(Arrays.asList("Sujon", "Emon", "Mahin", "Sujon", "Farhan"));

        //Create HashSet from list (duplicates removed)
        HashSet<String> set = new HashSet<>(list);
        System.out.println("HashSet (duplicates removed): " + set);

        //Add new name
        set.add("Kawsar");
        System.out.println("After adding Kawsar: " + set);

        //Check size
        System.out.println("Set size: " + set.size());

        //Iterate using Iterator
        System.out.println("Iterating over HashSet:");
        Iterator<String> iterator = set.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        //Set operations
        HashSet<String> setA = new HashSet<>(Arrays.asList("Sujon", "Emon", "Kawsar"));
        HashSet<String> setB = new HashSet<>(Arrays.asList("Emon", "Sojib", "Soikot"));

        // Union
        HashSet<String> union = new HashSet<>(setA);
        union.addAll(setB);
        System.out.println("Union: " + union);

        // Intersection
        HashSet<String> intersection = new HashSet<>(setA);
        intersection.retainAll(setB);
        System.out.println("Intersection: " + intersection);

        // Subset check
        boolean isSubset = setA.containsAll(intersection);
        System.out.println("Is Intersection a subset of Set A:" + isSubset);
    }
    
}
