package arraylistexample;
import java.util.*;
public class ArrayListExample {
    public static void main(String[] args) {
        
        // Create ArrayList to store student names
        ArrayList<String> nameList = new ArrayList<String>();
        
        // Adding names including duplicates
        nameList.add("Emon");
        nameList.add("Mahmud");
        nameList.add("Kawsar");
        nameList.add("Emon");  
        nameList.add("Minhaj");
        nameList.add("Farhan");
        nameList.add("Mahin");
        
       
        // Print all names
        System.out.println("All Names: " + nameList);
        
        // Remove one name by value
        nameList.remove("Mahmud");
        System.out.println("After Removing 'Mahmud': " + nameList);
        
        // Update a name at a specific index
        nameList.set(1, "Sujon"); 
        System.out.println("After Updating Index 1: " + nameList);
        
        // Check if a name exists
        String checkName = "Emon";
        if(nameList.contains(checkName)) {
            System.out.println(checkName + " exists in the list.");
        } else {
            System.out.println(checkName + " does not exist in the list.");
        }        
        Collections.sort(nameList);
        System.out.println("Sorted List: " + nameList);
    }
}
