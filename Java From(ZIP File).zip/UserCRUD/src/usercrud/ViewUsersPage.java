package usercrud;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ViewUsersPage extends JFrame {

    final String URL = "jdbc:mysql://localhost:3306/shariful";
    final String USER = "root";
    final String PASS = "";

    JTable table;
    DefaultTableModel model;

    JTextField txtId, txtName, txtEmail, txtPhone;

    public ViewUsersPage() {

        setTitle("View / Update / Delete Users");
        setSize(700, 500);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lblTitle = new JLabel("User List");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setBounds(280, 10, 200, 30);
        add(lblTitle);

        // Table
        model = new DefaultTableModel();
        model.addColumn("User ID");
        model.addColumn("Name");
        model.addColumn("Email");
        model.addColumn("Phone");

        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(30, 50, 620, 180);
        add(sp);

        // Labels
        JLabel lblId = new JLabel("User ID:");
        JLabel lblName = new JLabel("Name:");
        JLabel lblEmail = new JLabel("Email:");
        JLabel lblPhone = new JLabel("Phone:");

        lblId.setBounds(50, 250, 80, 25);
        lblName.setBounds(50, 290, 80, 25);
        lblEmail.setBounds(350, 250, 80, 25);
        lblPhone.setBounds(350, 290, 80, 25);

        add(lblId);
        add(lblName);
        add(lblEmail);
        add(lblPhone);

        // TextFields
        txtId = new JTextField();
        txtName = new JTextField();
        txtEmail = new JTextField();
        txtPhone = new JTextField();

        txtId.setBounds(130, 250, 150, 25);
        txtName.setBounds(130, 290, 150, 25);
        txtEmail.setBounds(430, 250, 150, 25);
        txtPhone.setBounds(430, 290, 150, 25);

        txtId.setEditable(false);

        add(txtId);
        add(txtName);
        add(txtEmail);
        add(txtPhone);

        // Buttons
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        JButton btnRefresh = new JButton("Refresh");

        btnUpdate.setBounds(180, 350, 100, 35);
        btnDelete.setBounds(300, 350, 100, 35);
        btnRefresh.setBounds(420, 350, 100, 35);

        add(btnUpdate);
        add(btnDelete);
        add(btnRefresh);

        // Load data
        loadUsers();

        // Row click → load into fields
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();

                txtId.setText(model.getValueAt(row, 0).toString());
                txtName.setText(model.getValueAt(row, 1).toString());
                txtEmail.setText(model.getValueAt(row, 2).toString());
                txtPhone.setText(model.getValueAt(row, 3).toString());
            }
        });

        // UPDATE
        btnUpdate.addActionListener(e -> updateUser());

        // DELETE
        btnDelete.addActionListener(e -> deleteUser());

        // REFRESH
        btnRefresh.addActionListener(e -> refreshTable());

        setVisible(true);
    }

    // Load users
    private void loadUsers() {
        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM userinfo")) {

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("userid"),
                        rs.getString("username"),
                        rs.getString("email"),
                        rs.getString("phone")
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    // UPDATE user
    private void updateUser() {

        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a user first!");
            return;
        }

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pst = con.prepareStatement(
                     "UPDATE userinfo SET username=?, email=?, phone=? WHERE userid=?")) {

            pst.setString(1, txtName.getText());
            pst.setString(2, txtEmail.getText());
            pst.setString(3, txtPhone.getText());
            pst.setInt(4, Integer.parseInt(txtId.getText()));

            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "User Updated Successfully");
            refreshTable();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    // DELETE user
    private void deleteUser() {

        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a user first!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete this user?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection con = DriverManager.getConnection(URL, USER, PASS);
                 PreparedStatement pst = con.prepareStatement(
                         "DELETE FROM userinfo WHERE userid=?")) {

                pst.setInt(1, Integer.parseInt(txtId.getText()));
                pst.executeUpdate();

                JOptionPane.showMessageDialog(this, "User Deleted Successfully");
                refreshTable();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        }
    }

    // Refresh table
    private void refreshTable() {
        model.setRowCount(0);
        loadUsers();

        txtId.setText("");
        txtName.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
    }
}
