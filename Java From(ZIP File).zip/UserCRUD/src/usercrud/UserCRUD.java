package usercrud;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class UserCRUD extends JFrame {

    JTextField txtId, txtName, txtEmail, txtPhone;

    final String URL = "jdbc:mysql://localhost:3306/shariful";
    final String USER = "root";
    final String PASS = "";

    public UserCRUD() {

        setTitle("User Management System");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(240, 248, 255)); // light blue

        Font labelFont = new Font("Segoe UI", Font.PLAIN, 16);

        JLabel lblTitle = new JLabel("User Information");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setBounds(160, 20, 250, 30);
        add(lblTitle);

        JLabel lblId = new JLabel("User ID");
        JLabel lblName = new JLabel("Name");
        JLabel lblEmail = new JLabel("Email");
        JLabel lblPhone = new JLabel("Phone");

        lblId.setBounds(70, 80, 100, 25);
        lblName.setBounds(70, 130, 100, 25);
        lblEmail.setBounds(70, 180, 100, 25);
        lblPhone.setBounds(70, 230, 100, 25);

        lblId.setFont(labelFont);
        lblName.setFont(labelFont);
        lblEmail.setFont(labelFont);
        lblPhone.setFont(labelFont);

        add(lblId);
        add(lblName);
        add(lblEmail);
        add(lblPhone);

        txtId = new JTextField();
        txtName = new JTextField();
        txtEmail = new JTextField();
        txtPhone = new JTextField();

        txtId.setBounds(180, 80, 220, 30);
        txtName.setBounds(180, 130, 220, 30);
        txtEmail.setBounds(180, 180, 220, 30);
        txtPhone.setBounds(180, 230, 220, 30);

        add(txtId);
        add(txtName);
        add(txtEmail);
        add(txtPhone);

        JButton btnInsert = createButton("Insert");
        JButton btnRead = createButton("Read");
        JButton btnExit = createButton("Exit");

        btnInsert.setBounds(70, 300, 100, 40);
        btnRead.setBounds(190, 300, 100, 40);
        btnExit.setBounds(310, 300, 100, 40);

        add(btnInsert);
        add(btnRead);
        add(btnExit);

        // INSERT
        btnInsert.addActionListener(e -> insertUser());

        // READ (Open new page)
        btnRead.addActionListener(e -> new ViewUsersPage());

        // EXIT
        btnExit.addActionListener(e -> System.exit(0));

        setVisible(true);
    }

    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(new Color(30, 144, 255)); // blue
        btn.setForeground(Color.white);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 1, true));
        return btn;
    }

    private void insertUser() {
        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pst = con.prepareStatement(
                     "INSERT INTO userinfo(userid, username, email, phone) VALUES (?,?,?,?)")) {

            pst.setInt(1, Integer.parseInt(txtId.getText()));
            pst.setString(2, txtName.getText());
            pst.setString(3, txtEmail.getText());
            pst.setString(4, txtPhone.getText());
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Insert Successful!");

            txtId.setText("");
            txtName.setText("");
            txtEmail.setText("");
            txtPhone.setText("");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new UserCRUD();
    }
}