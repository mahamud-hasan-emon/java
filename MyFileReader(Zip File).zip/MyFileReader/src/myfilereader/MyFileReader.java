package myfilereader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;

public class MyFileReader {

    public static void main(String[] args) {
        // File path of the text file to read
        String fileName = "E:\\Myfie.txt";
        
        // Variable to store each line from the file
        String line = null;

        try {
            // Create a FileReader to read the file
            java.io.FileReader fileReader = new java.io.FileReader(fileName);
            
            // Wrap FileReader inside BufferedReader for efficient reading
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            // Read the file line by line until reaching the end
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);  // Print each line to the console
            }

            // Close the BufferedReader after finishing reading
            bufferedReader.close();
            
        } catch (FileNotFoundException ex) {
            // This block runs if the file is not found
            System.out.println("Unable to open file '" + fileName + "'");
            
        } catch (IOException ex) {
            // This block runs if there is an error while reading the file
            System.out.println("Error reading file '" + fileName + "'");
        }
    }
}

