package appendfilewrite;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
public class AppendFileWrite {
  public static void main(String[] args) {
        
        // The name (path) of the file where data will be written
        String fileName = "E:\\MyWritenFile1.txt";

        try {
            // FileWriter in append mode (true = append, false = overwrite)
            FileWriter fileWriter = new FileWriter(fileName, true);

            // BufferedWriter for efficient writing
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter); 
            
            // Writing text to the file
            bufferedWriter.newLine();  // Add a blank line before new data
            bufferedWriter.write("Hello Everyone,");
            bufferedWriter.newLine();
            bufferedWriter.write("Myself Md.Mahamud Hasan Emon.");
            bufferedWriter.newLine();
            bufferedWriter.write("My Id:2241081405");
            bufferedWriter.newLine();
            bufferedWriter.write("My Batch:61(B)");
            bufferedWriter.newLine();
            bufferedWriter.write("Have a nice day!");
            
            // Close writer
            bufferedWriter.close();
        }
        catch(IOException ex) {
            // If any error occurs
            System.out.println("Error writing to file '" + fileName + "'");
        }
    }
}
