package myfilewriter;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class MyFileWriter {

    public static void main(String[] args) {
        
        // The name (path) of the file where data will be written
        String fileName = "E:\\MyWritenFile.txt";

        try {
            // Create a FileWriter to write data to the file
            // This uses the system's default character encoding
            FileWriter fileWriter = new FileWriter(fileName);

            // Wrap FileWriter inside BufferedWriter for efficient writing
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter); 
            
            // Writing text to the file
            bufferedWriter.write("Md.Mahamud Hasan Emon.");
            bufferedWriter.newLine(); // Write a new line
            
            bufferedWriter.write("My Id:2241081405");
            bufferedWriter.newLine();
            
            bufferedWriter.write("My Batch:61(B)");
            
            // Always close the writer after finishing
            bufferedWriter.close();
        }
        catch(IOException ex) {
            // Runs if any error occurs while writing to the file
            System.out.println("Error writing to file '" + fileName + "'");
        }
    }
}
